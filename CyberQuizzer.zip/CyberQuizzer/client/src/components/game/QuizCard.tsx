import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle2, XCircle, ChevronRight, Terminal, Shield, AlertCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Question } from "@/data/questions";
import { Badge } from "@/components/ui/badge";

interface QuizCardProps {
  question: Question;
  questionIndex: number;
  totalQuestions: number;
  onAnswer: (isCorrect: boolean) => void;
  onNext: () => void;
}

export function QuizCard({ question, questionIndex, totalQuestions, onAnswer, onNext }: QuizCardProps) {
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleOptionClick = (index: number) => {
    if (isSubmitted) return;
    setSelectedOption(index);
  };

  const handleSubmit = () => {
    if (selectedOption === null) return;
    setIsSubmitted(true);
    onAnswer(selectedOption === question.correctAnswer);
  };

  const isCorrect = selectedOption === question.correctAnswer;
  const progress = ((questionIndex) / totalQuestions) * 100;

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div className="mb-6 space-y-2">
        <div className="flex justify-between text-sm font-mono text-muted-foreground">
          <span>SESSION_ID: 0x{question.id.toString(16).padStart(4, '0')}</span>
          <span>PROGRESS: {questionIndex + 1}/{totalQuestions}</span>
        </div>
        <Progress value={progress} className="h-2 bg-secondary" />
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={question.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
        >
          <Card className="border-2 border-border/50 shadow-xl bg-card/50 backdrop-blur-sm overflow-hidden">
            <CardHeader className="border-b border-border/50 pb-4">
              <div className="flex items-center justify-between mb-2">
                <Badge variant="outline" className="font-mono text-xs uppercase tracking-widest border-primary/50 text-primary">
                  {question.category}
                </Badge>
                <Shield className="w-4 h-4 text-muted-foreground opacity-50" />
              </div>
              <CardTitle className="text-xl md:text-2xl font-medium leading-relaxed">
                {question.text}
              </CardTitle>
            </CardHeader>
            
            <CardContent className="pt-6">
              <div className="grid gap-3">
                {question.options.map((option, index) => {
                  let variant = "outline";
                  let className = "justify-start text-left h-auto py-4 px-6 border-2 hover:bg-secondary/50 hover:border-primary/50 transition-all";
                  
                  if (isSubmitted) {
                    if (index === question.correctAnswer) {
                      className += " border-green-500 bg-green-500/10 text-green-700 dark:text-green-400";
                    } else if (index === selectedOption && index !== question.correctAnswer) {
                      className += " border-red-500 bg-red-500/10 text-red-700 dark:text-red-400";
                    } else {
                      className += " opacity-50";
                    }
                  } else if (selectedOption === index) {
                    className += " border-primary bg-primary/5 ring-1 ring-primary";
                  }

                  return (
                    <Button
                      key={index}
                      variant="ghost"
                      className={className}
                      onClick={() => handleOptionClick(index)}
                      disabled={isSubmitted}
                    >
                      <span className="font-mono mr-4 text-muted-foreground">
                        {String.fromCharCode(65 + index)}.
                      </span>
                      <span className="font-medium text-base">{option}</span>
                      
                      {isSubmitted && index === question.correctAnswer && (
                        <CheckCircle2 className="ml-auto w-5 h-5 text-green-500" />
                      )}
                      {isSubmitted && index === selectedOption && index !== question.correctAnswer && (
                        <XCircle className="ml-auto w-5 h-5 text-red-500" />
                      )}
                    </Button>
                  );
                })}
              </div>

              <div className="mt-8 flex items-center justify-between min-h-[80px]">
                {!isSubmitted ? (
                  <Button 
                    className="w-full md:w-auto md:ml-auto font-bold tracking-wide" 
                    size="lg"
                    onClick={handleSubmit}
                    disabled={selectedOption === null}
                  >
                    EXECUTE <Terminal className="w-4 h-4 ml-2" />
                  </Button>
                ) : (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    className="w-full bg-muted/30 rounded-lg p-4 border border-border"
                  >
                    <div className="flex items-start gap-3">
                      <div className={`mt-1 p-1 rounded-full ${isCorrect ? 'bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400' : 'bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400'}`}>
                        {isCorrect ? <CheckCircle2 className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
                      </div>
                      <div className="flex-1">
                        <p className="font-semibold text-sm mb-1">
                          {isCorrect ? "Access Granted" : "Access Denied"}
                        </p>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          {question.explanation}
                        </p>
                      </div>
                      <Button onClick={onNext} size="sm" className="shrink-0">
                        Next <ChevronRight className="w-4 h-4 ml-1" />
                      </Button>
                    </div>
                  </motion.div>
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
