export interface Question {
  id: number;
  text: string;
  options: string[];
  correctAnswer: number; // Index of the correct answer (0-3)
  explanation: string;
  category: "Linux" | "PowerShell" | "Networking" | "Security";
}

export const questions: Question[] = [
  // Linux Basics
  {
    id: 1,
    text: "Which command is used to list files in the current directory in Linux?",
    options: ["list", "ls", "dir", "show"],
    correctAnswer: 1,
    explanation: "'ls' stands for 'list segments' and displays the contents of a directory.",
    category: "Linux"
  },
  {
    id: 2,
    text: "How do you check your current working directory in Linux?",
    options: ["whereami", "pwd", "cd", "path"],
    correctAnswer: 1,
    explanation: "'pwd' stands for 'print working directory' and outputs the full path of the current folder.",
    category: "Linux"
  },
  {
    id: 3,
    text: "Which command creates a new directory?",
    options: ["mkdir", "newdir", "create", "mkfile"],
    correctAnswer: 0,
    explanation: "'mkdir' stands for 'make directory'.",
    category: "Linux"
  },
  
  // PowerShell
  {
    id: 4,
    text: "In PowerShell, which cmdlet lists running processes?",
    options: ["Show-Process", "List-Tasks", "Get-Process", "ps-list"],
    correctAnswer: 2,
    explanation: "PowerShell uses the Verb-Noun syntax. 'Get-Process' retrieves the list of active processes.",
    category: "PowerShell"
  },
  {
    id: 5,
    text: "Which PowerShell command changes the security policy for running scripts?",
    options: ["Change-Policy", "Set-ExecutionPolicy", "Unblock-Script", "Grant-Permission"],
    correctAnswer: 1,
    explanation: "'Set-ExecutionPolicy' determines which PowerShell scripts (if any) can be run on the system.",
    category: "PowerShell"
  },

  // Networking
  {
    id: 6,
    text: "Which tool is used to test connectivity to another host by sending ICMP echo requests?",
    options: ["pong", "call", "ping", "echo"],
    correctAnswer: 2,
    explanation: "'ping' sends packets to a destination to verify connectivity and measure response time.",
    category: "Networking"
  },
  {
    id: 7,
    text: "Which command displays network configuration details (IP address, Subnet Mask) on Windows?",
    options: ["ifconfig", "ipconfig", "netstat", "showip"],
    correctAnswer: 1,
    explanation: "'ipconfig' is the standard Windows utility. On Linux/macOS, you would traditionally use 'ifconfig' or 'ip a'.",
    category: "Networking"
  },
  {
    id: 8,
    text: "What tool shows the path packets take to reach a destination?",
    options: ["pathfinder", "route-map", "traceroute", "walker"],
    correctAnswer: 2,
    explanation: "'traceroute' (or 'tracert' on Windows) maps the hops packets take across the network.",
    category: "Networking"
  },

  // Security / Shortcuts
  {
    id: 9,
    text: "Which keyboard shortcut instantly locks your Windows workstation?",
    options: ["Ctrl + L", "Alt + F4", "Win + L", "Ctrl + Alt + Del"],
    correctAnswer: 2,
    explanation: "Win + L is the quickest way to secure your session when stepping away from your desk.",
    category: "Security"
  },
  {
    id: 10,
    text: "Which concept refers to the principle of giving users only the permissions they need?",
    options: ["Least Privilege", "Zero Trust", "Defense in Depth", "Admin Access"],
    correctAnswer: 0,
    explanation: "The Principle of Least Privilege ensures users have the bare minimum access rights required to perform their job.",
    category: "Security"
  }
];
