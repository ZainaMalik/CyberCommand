import { useState } from "react";
import { QuizCard } from "@/components/game/QuizCard";
import { questions, Question } from "@/data/questions";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Trophy, RotateCcw, ShieldCheck, Terminal, Network, Lock, ChevronRight, Command } from "lucide-react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";

type Category = "Linux" | "PowerShell" | "Networking" | "Security" | "All";

export default function Home() {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [gameStatus, setGameStatus] = useState<"welcome" | "category_select" | "playing" | "finished">("welcome");
  const [selectedCategory, setSelectedCategory] = useState<Category>("All");

  const categories: { id: Category; label: string; icon: any; description: string; color: string }[] = [
    { 
      id: "Linux", 
      label: "Linux Command Line", 
      icon: Terminal, 
      description: "Master the penguin. File systems, permissions, and bash basics.",
      color: "text-yellow-500"
    },
    { 
      id: "PowerShell", 
      label: "PowerShell Ops", 
      icon: Command, 
      description: "Windows automation and administration mastery.",
      color: "text-blue-500"
    },
    { 
      id: "Networking", 
      label: "Network Recon", 
      icon: Network, 
      description: " protocols, ports, and connectivity tools.",
      color: "text-green-500"
    },
    { 
      id: "Security", 
      label: "SecOps & Safety", 
      icon: Lock, 
      description: "Best practices, encryption, and operational security.",
      color: "text-red-500"
    }
  ];

  const filteredQuestions = selectedCategory === "All" 
    ? questions 
    : questions.filter(q => q.category === selectedCategory);

  const handleStart = () => {
    setGameStatus("category_select");
  };

  const handleCategorySelect = (category: Category) => {
    setSelectedCategory(category);
    setScore(0);
    setCurrentQuestionIndex(0);
    setGameStatus("playing");
  };

  const handleAnswer = (isCorrect: boolean) => {
    if (isCorrect) {
      setScore((prev) => prev + 1);
    }
  };

  const handleNext = () => {
    if (currentQuestionIndex + 1 < filteredQuestions.length) {
      setCurrentQuestionIndex((prev) => prev + 1);
    } else {
      setGameStatus("finished");
    }
  };

  const handleRestart = () => {
    setGameStatus("category_select");
    setScore(0);
    setCurrentQuestionIndex(0);
  };

  const getScoreMessage = () => {
    const percentage = (score / filteredQuestions.length) * 100;
    if (percentage === 100) return "Perfect Score! You are a Cyber Master.";
    if (percentage >= 80) return "Great job! Access Granted.";
    if (percentage >= 60) return "Not bad, but more training required.";
    return "Access Denied. Please review the manual.";
  };

  return (
    <div className="min-h-screen w-full bg-background bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-background via-background to-muted/20 text-foreground p-4 flex flex-col items-center justify-center overflow-hidden relative">
      
      {/* Background Grid Effect */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none z-0" />

      {/* Header Logo Area */}
      <div className="absolute top-6 left-6 flex items-center gap-2 opacity-80 z-10">
        <div className="h-8 w-8 bg-primary rounded-sm flex items-center justify-center text-primary-foreground font-bold text-lg shadow-glow">
          C
        </div>
        <span className="font-mono font-bold tracking-tighter text-xl">CYBER_COMMAND</span>
      </div>

      <main className="w-full max-w-5xl mx-auto flex-1 flex flex-col items-center justify-center z-10 relative">
        
        {/* WELCOME SCREEN */}
        {gameStatus === "welcome" && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center space-y-8"
          >
            <div className="space-y-4">
              <div className="inline-flex items-center justify-center p-6 rounded-full bg-primary/10 text-primary mb-4 ring-1 ring-primary/20 shadow-[0_0_30px_-10px_rgba(var(--primary),0.3)]">
                <ShieldCheck className="w-16 h-16" />
              </div>
              <h1 className="text-4xl md:text-7xl font-extrabold tracking-tight mb-4">
                Ready to Test Your <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-primary to-accent animate-pulse">Security Skills?</span>
              </h1>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
                Enter the command center. Choose your specialization. Prove your knowledge.
              </p>
            </div>
            
            <Button 
              size="lg" 
              className="text-lg h-14 px-10 font-mono font-bold shadow-lg shadow-primary/20 hover:shadow-primary/40 hover:scale-105 transition-all duration-300 rounded-none border-2 border-primary/50"
              onClick={handleStart}
            >
              INITIALIZE_SYSTEM
            </Button>
          </motion.div>
        )}

        {/* CATEGORY SELECTION */}
        {gameStatus === "category_select" && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="w-full"
          >
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tight mb-2">Select Mission Profile</h2>
              <p className="text-muted-foreground">Choose a specialized training module to begin.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full max-w-4xl mx-auto px-4">
              {categories.map((cat) => (
                <motion.div
                  key={cat.id}
                  whileHover={{ scale: 1.02, y: -5 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Card 
                    className="cursor-pointer hover:border-primary/50 hover:bg-secondary/30 transition-all duration-300 h-full border-2 border-border/60 group"
                    onClick={() => handleCategorySelect(cat.id)}
                  >
                    <CardHeader className="flex flex-row items-center gap-4 pb-2">
                      <div className={`p-3 rounded-lg bg-muted group-hover:bg-background transition-colors ring-1 ring-border group-hover:ring-primary/30 ${cat.color}`}>
                        <cat.icon className="w-8 h-8" />
                      </div>
                      <div>
                        <CardTitle className="text-xl">{cat.label}</CardTitle>
                        <CardDescription className="font-mono text-xs mt-1">MODULE_ID: {cat.id.toUpperCase()}</CardDescription>
                      </div>
                      <ChevronRight className="ml-auto w-6 h-6 text-muted-foreground group-hover:text-primary transition-transform group-hover:translate-x-1" />
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground text-sm leading-relaxed">
                        {cat.description}
                      </p>
                      <div className="mt-4 flex items-center gap-2">
                        <Badge variant="secondary" className="text-xs font-mono">
                          {questions.filter(q => q.category === cat.id).length} LEVELS
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {/* PLAYING GAME */}
        {gameStatus === "playing" && filteredQuestions.length > 0 && (
          <QuizCard
            key={currentQuestionIndex}
            question={filteredQuestions[currentQuestionIndex]}
            questionIndex={currentQuestionIndex}
            totalQuestions={filteredQuestions.length}
            onAnswer={handleAnswer}
            onNext={handleNext}
          />
        )}

        {/* GAME FINISHED */}
        {gameStatus === "finished" && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="w-full max-w-md"
          >
            <Card className="border-2 border-border shadow-2xl bg-card/80 backdrop-blur overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary to-transparent opacity-50" />
              <CardHeader className="text-center pt-10 pb-6">
                <motion.div 
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", damping: 12 }}
                  className="mx-auto w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mb-6 ring-4 ring-background shadow-xl relative"
                >
                  <Trophy className="w-12 h-12 text-primary" />
                  <div className="absolute inset-0 rounded-full border border-primary/20 animate-ping" />
                </motion.div>
                <Badge variant="outline" className="mb-4 mx-auto w-fit border-primary/30 text-primary">
                  MODULE: {selectedCategory.toUpperCase()}
                </Badge>
                <CardTitle className="text-3xl font-bold">Mission Debrief</CardTitle>
                <p className="text-muted-foreground mt-2 font-medium px-4">{getScoreMessage()}</p>
              </CardHeader>
              <CardContent className="space-y-6 pb-10">
                <div className="bg-muted/30 rounded-xl p-8 text-center border border-border/50 relative overflow-hidden">
                  <div className="absolute inset-0 bg-grid-white/5 [mask-image:linear-gradient(0deg,white,rgba(255,255,255,0.6))] -z-10" />
                  <span className="text-sm font-mono uppercase tracking-wider text-muted-foreground">Final Score</span>
                  <div className="text-6xl font-extrabold text-primary mt-2 tracking-tight">
                    {score} <span className="text-2xl text-muted-foreground/50">/ {filteredQuestions.length}</span>
                  </div>
                </div>
                
                <div className="flex flex-col gap-3">
                  <Button className="w-full h-12 text-lg font-bold" onClick={handleRestart}>
                    <RotateCcw className="w-4 h-4 mr-2" /> Select New Mission
                  </Button>
                  <Button variant="outline" className="w-full" onClick={() => {
                     setScore(0);
                     setCurrentQuestionIndex(0);
                     setGameStatus("playing");
                  }}>
                    Retry This Level
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

      </main>

      {/* Footer Stats */}
      <footer className="w-full py-6 text-center text-sm text-muted-foreground font-mono z-10">
        <p>SYSTEM_STATUS: ONLINE | v1.0.1</p>
      </footer>
    </div>
  );
}
